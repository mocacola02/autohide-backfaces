# Auto-Hide Backfaces
Automatic backface hider for Blender 5, intended for interior modeling using objects with flipped normals.
This is my first Blender extension, so some jank and bugs are to be expected.
